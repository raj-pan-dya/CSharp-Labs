﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductTest
{
    class Program
    {

        static void Main(string[] args)
        {
            try
            {
                ProductMock obP = GetProductDetails();
                if(ProductMock.ValidateId(obP.ProductId, obP.ProductName,obP.Price))
                DisplayDetails(obP);
            
        }
            catch (DataEntryException objExp)
            {
                Console.WriteLine(objExp.Message);
            }


}

        public static ProductMock GetProductDetails()
        {
            ProductMock objProduct = new ProductMock();
            
                Console.WriteLine("Enter the Details of Products");
               
                Console.Write("Enter the Product ID: ");
                objProduct.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the Product Name: ");
                objProduct.ProductName = Console.ReadLine();
                Console.Write("Enter the Product Price: ");
                objProduct.Price = Convert.ToInt32(Console.ReadLine());
            ProductMock.ValidateId(objProduct.ProductId, objProduct.ProductName, objProduct.Price);


            return objProduct;

        }

        public static void DisplayDetails(ProductMock product)
        {
            Console.WriteLine(product.ProductId + " " + product.ProductName);
        }
    }
}
