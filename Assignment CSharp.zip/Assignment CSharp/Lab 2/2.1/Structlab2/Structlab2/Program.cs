﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structlab2
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int result;
            int choice;
            SquareCubeStruct objSqrCube = new SquareCubeStruct();
            Console.WriteLine("Please choose the number");
            number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please choose 1 for square and 2 for cube");
            choice = Convert.ToInt32(Console.ReadLine());
            objSqrCube.GetResult(number);
            switch (choice)
            {
                case 1:
                    result = objSqrCube.number * objSqrCube.number;
                    Console.WriteLine("Square of the number is : " + result);
                    break;
                case 2:
                    result = objSqrCube.number * objSqrCube.number * objSqrCube.number;
                    Console.WriteLine("Cube of the number is : "+ result );
                    break;
                default:
                    Console.WriteLine("Choose either 1 or 2");
                    break;
            }
        }
    }
}
