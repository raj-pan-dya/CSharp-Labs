﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            BookDemo objBook = new BookDemo();
            Console.WriteLine("Enter the book details");

            for (int i = 0; i < objBook.bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < objBook.bookDetails.GetLength(1); j++)
                {
                    objBook.bookDetails[i, j] = Console.ReadLine();
                }
            }

            for (int j = 0; j < objBook.bookDetails.Length; j++)
            {
                Console.Write(" "+objBook.colName[j]);
                
            }

            Console.WriteLine("");

            for (int i = 0; i < objBook.bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < objBook.bookDetails.GetLength(1); j++)
                {
                    if (j == 3)
                    {
                        Console.WriteLine(" " + objBook.bookDetails[i, j] + "\t");
                    }
                    else
                    {
                        Console.Write(" " + objBook.bookDetails[i, j] + "\t");
                    }
                    
                }
            }
        }
    }
}
