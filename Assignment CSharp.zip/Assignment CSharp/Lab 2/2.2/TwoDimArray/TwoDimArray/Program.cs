﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDimArray
{
    class Program
    {
        static void Main(string[] args)
        {
            MultiplDArray();
        }
        static void MultiplDArray()
        {
            Console.WriteLine("Enter the number to be stored in the array: ");
            int[,] numbers = new int[5, 6];

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbers[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            //
            Console.WriteLine("Numbers in Multidimension array - Using for loop: ");
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    if (j == 5)
                    {
                        Console.WriteLine(numbers[i, j]);
                    }
                    else
                    {
                        Console.Write(numbers[i, j] + ", ");
                    }

                }
            }
        }
    }
}
