﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardBill
{
    public delegate void CreditDel();
    class CreditCard
    {
        // Creating Delegate event

        public event CreditDel Operation = null;

        private int _creditCardNo;
        public int CreditCardNo
        {
            get
            {
                return _creditCardNo;
            }
            set
            {
                _creditCardNo = value;
            }
        }
        private string _cardHolderName;
        public string CardHolderName
        {
            get
            {
                return _cardHolderName;
            }
            set
            {
                _cardHolderName = value;
            }
        }
        private int _balanceAmount;
        public int BalanceAmount
          {
            get
            {
                return _balanceAmount;
            }
            set
            {
                _balanceAmount = value;
            }
        } 
        private int _creditLimit;

        public int CreditLimit
        {
            get
            {
                return _creditLimit;
             }
            set
            {
                _creditLimit = value;
            }
        }

        //Function to get the balance amount of Credit Card
        public void GetBalance()
        {
            
            Console.WriteLine("Balance amount after payment " + BalanceAmount);
 
        }


        //No functionalities mentioned in Lab manual
        public int GetCreditLimit()
        {
            return 0;
        }

        //Function to make payment where event will be raised for Balance amount
        public void MakePayment(int payment)
        {
            BalanceAmount = BalanceAmount - payment;

            if (Operation != null)
            {
                Operation();
            }
            Console.WriteLine("Payment successful");
        }
    }
}
