﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardBill
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            CreditCard creditCardObj = new CreditCard();

            Console.WriteLine("Enter Credit Card Details...");
            Console.WriteLine("Enter Credit Card No.");
            creditCardObj.CreditCardNo = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Enter Credit Card Holder Name");
            creditCardObj.CardHolderName = Console.ReadLine();
            Console.WriteLine("Enter Credit amount");

            creditCardObj.BalanceAmount = Convert.ToInt32(Console.ReadLine()); ;

            //Event reference
            creditCardObj.Operation += new CreditDel(creditCardObj.GetBalance);

            Console.WriteLine("Enter Payment amount");

            int payment = Convert.ToInt32(Console.ReadLine());
            // Calling funation which contain operation event
            creditCardObj.MakePayment(payment);

        }
    }
}
