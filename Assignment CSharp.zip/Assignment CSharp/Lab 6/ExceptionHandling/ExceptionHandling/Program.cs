﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                CustomerInfo();
            }
            catch (InvalidCreditLimitExp objEx)
            {
                Console.WriteLine(objEx.Message);
            }
        }

        public static void CustomerInfo()
        {
            Customer objCustomer = new Customer();
           
                Console.WriteLine("Enter the details of Customer");
                Console.WriteLine("");
                Console.Write("Enter Customer Id: ");
                objCustomer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name: ");
                objCustomer.CustomerName = Console.ReadLine();
                Console.Write("Enter Customer Address: ");
                objCustomer.Address = Console.ReadLine();
                Console.Write("Enter City: ");
                objCustomer.City = Console.ReadLine();
                Console.Write("Enter Customer Phone: ");
                objCustomer.Phone = Console.ReadLine();
                Console.Write("Enter CreditLimit: ");
                objCustomer.CreditLimit = Convert.ToInt32(Console.ReadLine());

                Customer.ValidateCredit(objCustomer.CreditLimit);

                Console.WriteLine("");
            
        }
    }
}
