﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public abstract class BankAccount : IBankAccount
    {
        protected double balance;

        public void Deposit(double amount, BankAccountTypeEnum en)
        {
           if(en == BankAccountTypeEnum.Saving)
            {
                balance = balance + amount + CalculateInterest(amount);
            }
            else
            {
                balance = balance + amount;
            }
        }

        public double GetBalance()
        {
            return balance;
        }

        public abstract bool Withdraw(double amount);
        
        public abstract bool Transfer(IBankAccount toAccount, double amount);
       
        public BankAccountTypeEnum AccountType { get; set; }

        public abstract double CalculateInterest(double amount);
    }

    //Concrete Bank Account Classes having their own rules for Minimum Balance
    public class ICICI : BankAccount // Inherit this from BankAccount
    {
        public override bool Withdraw(double amount) // Override this method
        {
            // If Balance – amount is >= 0 then only WithDraw is possible.
            // Write the code to achieve the same.
            if ((balance - amount)>= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override bool Transfer(IBankAccount toAccount, double amount) //Override this method
        {
            // If Balance – Withdraw is >= 1000 then only transfer can take place.
            // Write the code to achieve the same.
            if ((balance - amount) >= 1000)
            {
                BankAccountTypeEnum value = BankAccountTypeEnum.Current;
                toAccount.Deposit(amount,value);
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }
        }
        public override double CalculateInterest(double amount)
        {
                double interest;
                return interest = ((amount * 7) / 100);
            
        }
    }

    public class HSBC : BankAccount // Inherit this from BankAccount
    {
        public override bool Withdraw(double amount) //Override this method
        {
            // If Balance – amount is >= 5000 then only WithDraw is possible.
            // Write the code to achieve the same.
            if ((balance - amount) >= 5000)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override bool Transfer(IBankAccount toAccount, double amount) //Override this method
        {
            // If Balance – Withdraw is >= 5000 then only transfer can take place.
            // Write the code to achieve the same.
            if ((balance - amount) >= 5000)
            {
                BankAccountTypeEnum value = BankAccountTypeEnum.Current;
                toAccount.Deposit(amount,value);
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }
        }
        public override double CalculateInterest(double amount)
        {
             double interest;
             return interest = ((amount * 5) / 100);
            
        }
    }
}
