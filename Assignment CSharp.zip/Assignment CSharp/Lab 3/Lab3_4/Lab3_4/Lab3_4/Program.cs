﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int supplierId;
            string supplierName, city, phonenum, email;

            Console.WriteLine("Enter Details");
            Console.WriteLine("Enter Id");
            supplierId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter city");
            city = Console.ReadLine();
            Console.WriteLine("Enter phonenum");
            phonenum = Console.ReadLine();
            Console.WriteLine("Enter email");
            email = Console.ReadLine();

            Supplier obj = new Supplier();
            obj.setDetails(supplierId,supplierName,city,phonenum,email);
            obj.displayDetails();
           
           





        }
    }
}
