﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice, no, index;
            char option;
            string[] colName = { "Sr No", "Makes", "Model", "Year", "Sales Price" };
            CarsCatalog[] car = new CarsCatalog[4];

            do
            {
                Console.WriteLine("Please choose what you want to do");
                Console.WriteLine(" ------------------------------------\n 1)Add \n 2)Search \n 3)Delete \n 4)Modify \n 5)Print \n 6)Exit \n------------------------------------");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("How many cars you have to add");
                        no = Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < no; i++)
                        {
                            car[i] = new CarsCatalog();
                            car[i].addCar();
                           
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter year of car");
                        int year2 = Convert.ToInt32(Console.ReadLine());
                        for (index = 0; index < car.Length; index++)
                        {
                            if (car[index].search(year2))
                            {
                                car[index].Print();
                            }
                            else
                            {
                                Console.WriteLine("Not found");
                            }
                        }
                        break;

                    case 3:
                        List<CarsCatalog> list = new List<CarsCatalog>(car);
                        Console.WriteLine("Enter year to delete");
                        int yr1 = Convert.ToInt32(Console.ReadLine());
                        for (index = 0; index < car.Length; index++)
                        {
                            if (car[index].year == yr1)
                            {
                                list.Remove(car[index]);
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Enter year of car");
                        int year1 = Convert.ToInt32(Console.ReadLine());
                        for (index = 0; index < car.Length; index++)
                        {
                            if (car[index].year == year1)
                            {
                                car[index].modify(car[index].srNo);

                            }
                        }
                        break;
                    case 5:
                        for (index = 0; index < colName.Length; index++)
                        {
                            Console.Write("\t" + colName[index]);
                        }
                        for (index = 0; index < car.Length; index++)
                        {
                            car[index].Print();
                        }
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                }
                Console.WriteLine("Press any key to continue or press 'N' to exit");
                option = Convert.ToChar(Console.ReadLine());
            } while (option != 'N' || option != 'n');
            

            }

            }
        }
    

