﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecords
{
    public class Records
    {
        int _rollNumber;
        string _studentName;
        byte _age;
        char _gender;
        DateTime _dateOfBirth;
        string _address;
        float _percentage;

        public int rollNumber
        {
            get
            {
                return _rollNumber;
            }
            set
            {
                _rollNumber = value;
            }
        }
        public string studentName
        {
            get
            {
                return _studentName;
            }
            set
            {
                _studentName = value;
            }
        }
        public byte age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
        public char gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }
        public DateTime dateOfBirth
        {
            get
            {
                return _dateOfBirth;
            }
            set
            {
                _dateOfBirth = value;
            }
        }
        public string address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        public float percentage
        {
            get
            {
                return _percentage;
            }
            set
            {
                _percentage = value;
            }
        }

        public Records()
        {

        }

        public Records(int rollNumber, string studentName, byte age, char gender, DateTime dateOfBirth, string address, float percentage)
        {
            this.rollNumber = rollNumber;
            this.studentName = studentName;
            this.age = age;
            this.gender = gender;
            this.dateOfBirth = dateOfBirth;
            this.address = address;
            this.percentage = percentage;
        }
    }
}
