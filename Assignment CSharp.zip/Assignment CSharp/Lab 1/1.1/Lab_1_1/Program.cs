﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1_lib;

namespace Lab_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
           /* Employee emp = new Employee();
            Console.WriteLine("Please Enter Employee Id");
            emp.EmployeeId = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Please Enter Employee Name");
            emp.EmployeeName = Console.ReadLine();
            Console.WriteLine("Please Enter Employee Address");
            emp.Address = Console.ReadLine();
            Console.WriteLine("Please Enter Employee Department");
            emp.City = Console.ReadLine();
            Console.WriteLine("Please Enter Employee Salary");
            emp.Salary = Convert.ToInt32(Console.ReadLine());
            */
            //Code to write the valaue in Console
            /*Console.WriteLine(emp.EmployeeId);
            Console.WriteLine(emp.EmployeeName);
            Console.WriteLine(emp.Address);
            Console.WriteLine(emp.City);
            Console.WriteLine(emp.Salary);
            Console.ReadLine();
            */

            Employee[] empArr = new Employee[10];
            for(int i = 0;i<empArr.Length;i++)
            {
                empArr[i] = new Employee();
                Console.WriteLine("Please Enter Employee Id");
                empArr[i].EmployeeId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please Enter Employee Name");
                empArr[i].EmployeeName = Console.ReadLine();
                Console.WriteLine("Please Enter Employee Address");
                empArr[i].Address = Console.ReadLine();
                Console.WriteLine("Please Enter Employee Department");
                empArr[i].City = Console.ReadLine();
                Console.WriteLine("Please Enter Employee Salary");
                empArr[i].Salary = Convert.ToInt32(Console.ReadLine());
                 }
          /*  for (int i = 0; i < empArr.Length; i++) {
                Console.WriteLine("Employee Details for index : " + i);
                Console.WriteLine("  Id        :"+empArr[i].EmployeeId);
                Console.WriteLine( "  Name    :" + empArr[i].EmployeeName);
                Console.WriteLine( "  Address  :" + empArr[i].Address);
                Console.WriteLine( "  City     :" + empArr[i].City);
                Console.WriteLine( "  Salary   :" + empArr[i].Salary);

            }*/
            foreach (Employee objemp in empArr)
            {
               
                Console.WriteLine("Employee Detail");
                Console.WriteLine("  Id        :" + objemp.EmployeeId);
                Console.WriteLine("  Name    :" + objemp.EmployeeName);
                Console.WriteLine("  Address  :" + objemp.Address);
                Console.WriteLine("  City     :" + objemp.City);
                Console.WriteLine("  Salary   :" + objemp.Salary);
            }
        }
    }
}
