﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLib;

namespace CalculatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------ Calculator Application ------");
            char flag;
            do
            {
                double operation, firstNo, secondNo, result;


                Console.WriteLine("Press 1 for Addition, 2 for Subtraction, 3 for Multiplication, 4 for Division, 5 for Modulus");

                operation = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter First No");
                firstNo = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Second No");
                secondNo = Convert.ToInt32(Console.ReadLine());

                ArithmeticOperations objCalculator = new ArithmeticOperations();

                switch (operation)
                {
                    case 1:
                        //Logic to Add
                        result = objCalculator.Addition(firstNo, secondNo);
                        Console.WriteLine("Addition of is " + result);
                        break;
                    case 2:
                        //Logic to Subtract
                        result = objCalculator.Subtraction(firstNo, secondNo);
                        Console.WriteLine("Subtraction is " + result);
                        break;
                    case 3:
                        //Logic to Multiply
                        result = objCalculator.Multiplication(firstNo, secondNo);
                        Console.WriteLine("Multiplication is " + result);
                        break;
                    case 4:
                        //Logic to Divide
                        result = objCalculator.Division(firstNo, secondNo);
                        Console.WriteLine("Division is " + result);
                        break;
                    case 5:
                        //Logic to Divide
                        result = objCalculator.Modulus(firstNo, secondNo);
                        Console.WriteLine("Modulus is " + result);
                        break;
                    default:
                        Console.WriteLine("Select the valid option!!!");
                        break;
                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue 'n' to exit");
                flag = Convert.ToChar(Console.ReadLine());

            } while (flag == 'y');
            //Console.ReadLine();
        }
    }
}
