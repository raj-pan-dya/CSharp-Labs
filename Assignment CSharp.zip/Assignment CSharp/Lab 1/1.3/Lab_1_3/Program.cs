﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int input,flag;
           
            do
            {
                input = Convert.ToInt32(Console.ReadLine());
                switch (input)

                {

                    case 1:
                    Console.WriteLine("This is 1st Case");
                    break;

                    case 2:
                    Console.WriteLine("This is 2nd Case");
                    break;

                    case 3:
                    Console.WriteLine("This is 3rd Case");
                    break;

                    case 4:
                    Console.WriteLine("This is 4th Case");
                    break;

                    case 5:
                    Console.WriteLine("This is 5th Case");
                    break;

                    default :
                    Console.WriteLine("This is default Case");

                    break;
            }
            Console.WriteLine("Do you want to continue? Press 'y' for yes 'n' for no");
            flag = Convert.ToChar(Console.ReadLine());
        } while (flag == 'y');
        }
    }
}
