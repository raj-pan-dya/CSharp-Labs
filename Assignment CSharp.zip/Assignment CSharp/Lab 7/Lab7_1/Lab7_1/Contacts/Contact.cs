﻿//<summary>
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Shariq Anwar Ansari
 * Desc                 : Program to maintain a Contact List in a generic List Collection.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
//</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts
{
    [Serializable]
    public class Contact
    {
       
        public int ContactNo { get; set; }
        public string ContactName { get; set; }
        public string CellNo { get; set; }
    }
}
