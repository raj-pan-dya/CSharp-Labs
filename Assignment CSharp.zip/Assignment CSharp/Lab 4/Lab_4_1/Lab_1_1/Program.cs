﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1_lib;

namespace Lab_1_1
{
    class Program
    {
        
        static void Main(string[] args)
        {

            int salary, employeeId;
            string employeeName, address, city, department;


          
            do
            {
                Console.WriteLine("Select the type of Employee...");
                Console.WriteLine("1. Permanent Employee Salary");
                Console.WriteLine("2. Contract Employee Salary");
                Console.WriteLine("3. EXIT");
                int input = Convert.ToInt32(Console.ReadLine());
               
                switch (input)
                {
                    
                    case 1:
                       
                        PermanentEmployee pmObj = new PermanentEmployee();
                        Console.WriteLine("Enter Salary ");
                        salary = Convert.ToInt32( Console.ReadLine()) ;
                        Console.WriteLine("Enter Id ");

                        employeeId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Name ");

                        employeeName = Console.ReadLine();
                        Console.WriteLine("Enter Address ");

                        address = Console.ReadLine();
                        Console.WriteLine("Enter City ");

                        city = Console.ReadLine();
                        Console.WriteLine("Enter Department ");

                        department = Console.ReadLine();
                        Console.WriteLine(" Salary Of Permanent Employee :" + pmObj.GetSalary( employeeName,address,  city, department,salary, employeeId ) );
                        break;
                    case 2:
                        ContractEmployee ceObj = new ContractEmployee();
                        Console.WriteLine("Enter Salary ");
                        salary = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Id ");

                        employeeId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Name ");

                        employeeName = Console.ReadLine();
                        Console.WriteLine("Enter Address ");

                        address = Console.ReadLine();
                        Console.WriteLine("Enter City ");

                        city = Console.ReadLine();
                        Console.WriteLine("Enter Department ");

                        department = Console.ReadLine();
                        Console.WriteLine("  Salary of Contract Employee :" + ceObj.GetSalary(employeeName, address, city, department, salary, employeeId));
                        break;
                    case 3:
                        return;
                }

            } while (true);
        }
    }
}
