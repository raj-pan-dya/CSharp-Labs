﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_lib
{
    class ContractEmployee: Employee
    {
        int perks;
        public int Perks
        {
            get
            {
                return perks;

            }
            set
            {

                perks = value;

            }


        }
        override public int GetSalary(string employeeName, string address, string city, string department, int salary, int employeeId)
        {
            
                Console.WriteLine("Please enter the perks of Contract Employee");
                Perks = Convert.ToInt32(Console.ReadLine());
           
            EmployeeName = employeeName;
            Address = address;
            City = city;
            Department = department;
            Salary = salary;
            EmployeeId = employeeId;
            return (Salary + Perks);
            
        }
    }
}
