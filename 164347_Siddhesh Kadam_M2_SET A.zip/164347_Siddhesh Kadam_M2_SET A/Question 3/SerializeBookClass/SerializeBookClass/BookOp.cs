﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SerializeBookClass
{
    [Serializable]      //For serializing the class

    class BookOp
    {
        public static void AddBook()
        {
            Book objBook = new Book();

            //Fetching Book details from user
            Console.WriteLine("Enter Book Details:");

            Console.WriteLine("Enter Book Id: ");
            objBook.BookID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Book Name: ");
            objBook.BookName = Console.ReadLine();

            Console.WriteLine("Enter ISBN No: ");
            objBook.ISBNNo= Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Price: ");
            objBook.Price = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Publisher Name: ");
            objBook.Publisher = Console.ReadLine();

            Console.WriteLine("Enter no of pages: ");
            objBook.NoOfPages = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Language: ");
            objBook.Language = Console.ReadLine();

            Console.WriteLine("Enter LoT: ");
            objBook.LoT = Console.ReadLine();

            Console.WriteLine("Enter Book Summary: ");
            objBook.Summary = Console.ReadLine();

            //Adding the book details in the list object
            Book.listObj.Add(objBook);
        }

        public static void DisplayBooks(List<Book> listObj)
        {
            Console.WriteLine("List of Book Details:");
            //Printing every book detail from the list object
            foreach (Book objBook in listObj)
            {
                Console.WriteLine("Book ID: {0}, Book Name: {1}, ISBN No: {2}, Price: {3}, Publisher: {4}, No of pages: {5}, Language: {6}, LoT: {7}, Summary: {8}", objBook.BookID, objBook.BookName, objBook.ISBNNo, objBook.Price, objBook.Publisher, objBook.NoOfPages, objBook.Language, objBook.LoT, objBook.Summary);
            }
        }

        //Serializing Book Details list using Binary Formatter 
        public static void SerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\siddkada\Desktop\164347_Siddhesh Kadam_M2_SET A\Question 3\BookDetails.dat", FileMode.Create);
            BinaryFormatter bin = new BinaryFormatter();  //Creating new binary formatter
            bin.Serialize(stream, Book.listObj);
            stream.Close();
        }
        
        //DeSerializing Book Details list using Binary Formatter 
        public static List<Book> DeSerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\siddkada\Desktop\164347_Siddhesh Kadam_M2_SET A\Question 3\BookDetails.dat", FileMode.Open);
            BinaryFormatter bin = new BinaryFormatter();  //Creating new binary formatter
            Book.listObj1 = bin.Deserialize(stream) as List<Book>;  //Stroing the details from derialized .dat file into new list object
            stream.Close();
            return Book.listObj1;
        }
    }
}
