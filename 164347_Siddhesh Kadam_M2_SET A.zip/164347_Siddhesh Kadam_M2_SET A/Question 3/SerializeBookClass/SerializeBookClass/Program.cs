﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializeBookClass
{
    class Program
    {
        static List<Book> book = new List<Book>();
        static void Main(string[] args)
        {
            char choice; //For providing user privilege to use program again without exiting, we use 'do while' loop.
            do
            {
                PrintMenu();    //To display a menu
                Console.WriteLine("Enter your choice: ");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());


                switch (taskFlag)
                {

                    case 1:
                        //Add book details
                        BookOp.AddBook();
                        break;

                    case 2:
                        //Serialize                         
                        BookOp.SerializeListBF();
                        break;

                    case 3:
                        //For deserializing
                        book = BookOp.DeSerializeListBF();
                        break;

                    case 4:
                        //Display Books
                        BookOp.DisplayBooks(book);

                        break;

                    default:
                        Console.WriteLine("Enter Correct Choice.");
                        break;

                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit.");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("****************************************");
            Console.WriteLine("Press 1 to Add Book Details");
            Console.WriteLine("Press 2 to Serialize List using BinaryFormatter");
            Console.WriteLine("Press 3 to DeSerialize List using BinaryFormatter");
            Console.WriteLine("Press 4 to Show All DeSerialized list of books");
            Console.WriteLine("****************************************");
        }
    }
}
