﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========Employee Details==========");

            //Creating Object of the class
            Employee objEmployee = new Employee();

            //Fetching employee details from the user and passing to the object
            Console.WriteLine("Enter the details");
            Console.WriteLine("Employee ID: ");
            objEmployee.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Employee Name: ");
            objEmployee.EmployeeName = Console.ReadLine();
            Console.WriteLine("Gender: ");
            objEmployee.Gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Date of Birth: ");
            objEmployee.DateOfBirth = Console.ReadLine();

            //To print the employee Details
            objEmployee.Print();
        }
    }
}
