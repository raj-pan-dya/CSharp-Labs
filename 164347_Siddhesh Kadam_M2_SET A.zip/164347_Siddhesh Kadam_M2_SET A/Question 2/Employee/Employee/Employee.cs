﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee : IPrintable  //interfaced with IPrintable
    {
        private int _employeeId;
        private string _employeeName;
        private char _gender;
        private string _dateOfBirth;

        //Creating Properties for parameters
        public int EmployeeID
        {
            get
            {
                return _employeeId;
            }
            set
            {
                _employeeId = value;
            }
        }

        public string EmployeeName
        {
            get
            {
                return _employeeName;
            }
            set
            {
                _employeeName = value;
            }
        }

        public char Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return _dateOfBirth;
            }
            set
            {
                _dateOfBirth = value;
            }
        }

        //For printing Employee details
        public void Print()
        {
            Console.WriteLine("Employee ID   : {0}", EmployeeID);
            Console.WriteLine("Employee Name : {0}", EmployeeName);
            Console.WriteLine("Gender        : {0}", Gender);
            Console.WriteLine("Date of Birth : {0}", DateOfBirth);            
        }
    }

}
