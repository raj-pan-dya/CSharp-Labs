﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMgmtSystem.Entities
{
    public class Book
    {
        private int _bookId;
        private string _bookName;
        private int _isbnNo;
        private int _price;
        private string _publisher;
        private int _noOfPages;
        private string _language;
        private string _lot;
        private string _summary;


        public int BookID
        {
            get { return _bookId; }
            set { _bookId = value; }
        }


        public string BookName
        {
            get { return _bookName; }
            set { _bookName = value; }
        }


        public int ISBNNo
        {
            get { return _isbnNo; }
            set { _isbnNo = value; }
        }

        public int Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public string Publisher
        {
            get { return _publisher; }
            set { _publisher = value; }
        }

        public int NoOfPages
        {
            get { return _noOfPages; }
            set { _noOfPages = value; }
        }

        public string Language
        {
            get { return _language; }
            set { _language = value; }
        }

        public string LoT
        {
            get { return _lot; }
            set { _lot = value; }
        }

        public string Summary
        {
            get { return _summary; }
            set { _summary = value; }
        }        
    }
}
