﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookMgmtSystem.Entities;
using BookMgmtSystem.Exceptions;
using BookMgmtSystem.DataAccessLayer;

namespace BookMgmtSystem.BusinessLayer
{
    public class BookBL
    {
        //====== Validations ======//
        private static bool ValidateBook(Book objBook)
        {
            StringBuilder objSB = new StringBuilder();
            bool validBook = true;
            if (objBook.BookID.ToString().Length != 5)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Invalid Book ID");
            }
            if (objBook.BookName == string.Empty)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Please Enter the Book Name");
            }
           
            if (objBook.LoT == ".NET" || objBook.LoT == "Java" || objBook.LoT == "IMS" || objBook.LoT == "V&V" || objBook.LoT == "BI" || objBook.LoT == "RDBMS")
            {
                validBook = true;
                if (objBook.LoT == string.Empty)
                {
                    validBook = true;
                    objBook.LoT = "Technical";
                }
                else
                {
                    validBook = false;
                    objSB.Append(Environment.NewLine + "Please select an option from the Book list");
                }
            }           
                       
            if (objBook.Language == string.Empty)
            {
                validBook = true;
                objBook.Language = "English";
            }
            if (validBook == false)
            {
                throw new BookMgmtSystemException(objSB.ToString());
            }
            return validBook;
        }

        //====== Validating Adding of Book Details ======//
        public static bool AddBookBL(Book objBook)
        {
            bool bookAdded = false;
            try
            {
                if (ValidateBook(objBook))
                {
                    BookDAL objBookDAL = new BookDAL();
                    bookAdded = objBookDAL.AddBookDAL(objBook);
                }
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                throw objBookMgmtExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookAdded;
        }

        //====== Validating Searching of Book ======//
        public static Book SearchBookBL(int bookId)
        {
            Book objBook;
            try
            {
                BookDAL objBookDAL= new BookDAL();
                objBook = objBookDAL.SearchBookDAL(bookId);
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                throw objBookMgmtExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objBook;
        }

        //====== Validating Displaying of Books ======//
        public static List<Book> DisplayBooksBL()
        {
            List<Book> objBookList = null;
            try
            {
                BookDAL objBookDAL = new BookDAL();
                objBookList = objBookDAL.DisplayBooksDAL();
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                throw objBookMgmtExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objBookList;
        }

        //====== Validating Deletion of a Book Detail ======//
        public static bool DeleteBookBL(int bookId)
        {
            bool bookDeleted = false;
            try
            {
                if (bookId > 0)
                {
                    BookDAL objBookDAL = new BookDAL();
                    bookDeleted = objBookDAL.DeleteBookDAL(bookId);
                }
                else
                {
                    throw new BookMgmtSystemException("Invalid Book ID");
                }
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                throw objBookMgmtExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookDeleted;
        }
    }
}
