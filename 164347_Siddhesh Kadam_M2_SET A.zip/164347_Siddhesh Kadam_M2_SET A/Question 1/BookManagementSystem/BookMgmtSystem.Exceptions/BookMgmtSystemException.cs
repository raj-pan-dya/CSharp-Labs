﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMgmtSystem.Exceptions
{
    public class BookMgmtSystemException : ApplicationException
    {
        public BookMgmtSystemException()
            : base()
        {
        }

        public BookMgmtSystemException(string message)
            : base(message)
        {
        }
        public BookMgmtSystemException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
