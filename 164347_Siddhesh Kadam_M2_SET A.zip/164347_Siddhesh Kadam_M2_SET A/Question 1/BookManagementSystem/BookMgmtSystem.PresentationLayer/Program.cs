﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookMgmtSystem.Entities;
using BookMgmtSystem.Exceptions;
using BookMgmtSystem.BusinessLayer;

namespace BookMgmtSystem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice.");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());
                switch (taskFlag)
                {
                    case 1:
                        //Add book
                        AddBook();
                        break;
                    case 2:
                        //Display all books
                        DisplayBooks();
                        break;
                    case 3:
                        //Delete book
                        DeleteBook();
                        break;                    
                    default:
                        Console.WriteLine("Enter correct choice");
                        break;
                }
                Console.WriteLine("Do you wish to continue? (Y/N): ");
                choice = Convert.ToChar(Console.ReadLine());

            } while (choice == 'y' || choice == 'Y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("======= Book Management System =======");
            Console.WriteLine("Press 1 to add a book entry");
            Console.WriteLine("Press 2 to display details of all books");
            Console.WriteLine("Press 3 to delete a book record");
        }

        static void AddBook()
        {
            try
            {
                Book objBook = new Book();
                
                //====== Accepting book details from user ======//
                Console.WriteLine("Enter book details: ");
                //Accept Book ID
                Console.WriteLine("Enter book ID: ");
                objBook.BookID = Convert.ToInt32(Console.ReadLine());
                //Accept Book Name
                Console.WriteLine("Enter the book name: ");
                objBook.BookName = Console.ReadLine();
                //Accept ISBN No
                Console.WriteLine("Enter ISBN no: ");
                objBook.ISBNNo = Convert.ToInt32(Console.ReadLine());
                //Accept Price Details
                Console.WriteLine("Enter price: ");
                objBook.Price = Convert.ToInt32(Console.ReadLine());
                //Accept Publisher Details
                Console.WriteLine("Enter publisher name: ");
                objBook.Publisher = Console.ReadLine();
                //Accept No of Pages in the book
                Console.WriteLine("Enter the no. of pages: ");
                objBook.NoOfPages = Convert.ToInt32(Console.ReadLine());
                //Accept Language
                Console.WriteLine("Enter language: ");
                objBook.Language = Console.ReadLine();                                            
                //Accept LoT
                Console.WriteLine("Enter LoT from below list: ");
                Console.WriteLine(".NET");
                Console.WriteLine("Java");
                Console.WriteLine("IMS");
                Console.WriteLine("V&V");
                Console.WriteLine("BI");
                Console.WriteLine("RDBMS");
                objBook.LoT = Console.ReadLine();               
                //Accept Book Summary
                Console.WriteLine("Enter summary: ");
                objBook.Summary = Console.ReadLine();

               
                //Verifying if book added or not
                bool bookAdded;
                bookAdded = BookBL.AddBookBL(objBook);
                if (bookAdded)
                {
                    Console.WriteLine("Book details added successfully!");
                }
                else
                {
                    Console.WriteLine("Book details not added!");
                }
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                Console.WriteLine(objBookMgmtExp.Message);
            }
        }

        static void DeleteBook()
        {
            try
            {
                int bookId;
                Console.WriteLine("Enter book ID to be deleted: ");
                bookId = Convert.ToInt32(Console.ReadLine());
                Book objBook;
                objBook = BookBL.SearchBookBL(bookId);

                if (objBook != null)
                {
                    bool bookDelete = BookBL.DeleteBookBL(bookId);
                    if (bookDelete)
                    {
                        Console.WriteLine("Book details deleted!");
                    }
                    else
                    {
                        Console.WriteLine("Book details NOT deleted!");
                    }
                }
                else
                {
                    Console.WriteLine("Book details not available!");
                }
            }
            catch (BookMgmtSystemException objBookMgmtExp)
            {
                Console.WriteLine(objBookMgmtExp.Message);
            }
        }

        static void DisplayBooks()
        {
            List<Book> objBook = BookBL.DisplayBooksBL();
            if (objBook != null)
            {
                foreach (var book in objBook)
                {
                    Console.WriteLine("\nBookID: {0}, Book Name: {1}, ISBN No: {2}, Price: {3}, Publisher: {4}, No. of pages: {5}, Language: {6}, LoT: {7}, Summary: {8}", book.BookID, book.BookName, book.ISBNNo, book.Price, book.Publisher, book.NoOfPages, book.Language, book.LoT, book.Summary);
                }
            }
            else
            {
                Console.WriteLine("Book Details not available");
            }

        }
    }
}
