﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookMgmtSystem.Entities;
using BookMgmtSystem.Exceptions;

namespace BookMgmtSystem.DataAccessLayer
{
    public class BookDAL
    {
        public static List<Book> bookList = new List<Book>();

        //====== Adding entries to the Book List =======//
        public bool AddBookDAL(Book newBook)
        {
            bool bookAdded = false;
            try
            {
                bookList.Add(newBook);
                bookAdded = true;
            }
            catch (SystemException ex)
            {
                throw new BookMgmtSystemException(ex.Message);
            }
            return bookAdded;
        }

        //====== Search for a book by ID =======//
        public Book SearchBookDAL(int bookId)
        {
            Book objBook = null;
            try
            {
                objBook = bookList.Find(book => book.BookID.Equals(bookId));
            }
            catch (SystemException objEx)
            {
                throw new BookMgmtSystemException(objEx.Message);
            }
            return objBook;
        }

        //====== Displaying all book details in the list ======//
        public List<Book> DisplayBooksDAL()
        {
            return bookList;
        }

        //====== Deleting a book record ======//
        public bool DeleteBookDAL(int deleteBookID)
        {
            bool bookDeleted = false;
            try
            {
                Book deleteBook = bookList.Find(book => book.BookID == deleteBookID);

                if (deleteBook != null)
                {
                    bookList.Remove(deleteBook);
                    bookDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new BookMgmtSystemException(ex.Message);
            }
            return bookDeleted;
        }
    }
}
