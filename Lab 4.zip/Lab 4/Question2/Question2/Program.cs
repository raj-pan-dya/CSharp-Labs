﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape s;
            Circle c;
            //stores object of triangle class.
            s = new Triangle();
            s.WhoamI();

            //stores object of Circle class.
            s = new Circle();
            s.WhoamI();

            //calls WhoamI() of Circle class.
            c = new Circle();
            c.WhoamI();
            Console.ReadKey();
        }
    }
}
