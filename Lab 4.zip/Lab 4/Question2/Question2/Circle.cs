﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public class Circle :  Shape
    {
        //Q3. Answer
        public new void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
}
