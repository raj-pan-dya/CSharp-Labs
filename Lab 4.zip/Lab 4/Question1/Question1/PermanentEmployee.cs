﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Question1
{
    public class PermanentEmployee : EmployeeClass
    {
        private double ProvidendFund;

        public double _ProvidendFund
        {
            get {
                return ProvidendFund;
            }
            set
            {
                ProvidendFund = value;
            }
        }
       
        //override method of base class.
        public override double getSalary()
        {
            EmpSalary = EmpSalary - ProvidendFund;
            return sal;
        }
    }
}
