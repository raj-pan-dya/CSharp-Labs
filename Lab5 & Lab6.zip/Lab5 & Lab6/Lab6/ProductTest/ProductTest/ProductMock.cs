﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductTest
{
    class ProductMock
    {
        int _productId;
        string _productName;
        double _price;

        public int ProductId
        {
            get { return _productId; }
            set { _productId = value; }
        }
        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public ProductMock()
        {

        }

        public ProductMock(int ProductId, string ProductName, double Price)
        {
            this.ProductId = ProductId;
            this.ProductName = ProductName;
            this.Price = Price;
        }

        public static void ValidateId(int ID)
        {
            if (ID < 0)
            {
                
                throw new DataEntryException("Product Id must be greater than 0!!!!!");
            }
            
        }
    }
}
