﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employees;

namespace Lab_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int employeeId;
            string employeeName;
            string employeeAddress;
            string employeeCity;
            string employeeDepartment;

           /* Console.WriteLine("Enter Employee ID");
            employeeId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Name");
            employeeName = Console.ReadLine();

            Console.WriteLine("Enter Employee Address");
            employeeAddress = Console.ReadLine();

            Console.WriteLine("Enter Employee City");
            employeeCity = Console.ReadLine();

            Console.WriteLine("Enter Employee Department");
            employeeDepartment = Console.ReadLine();*/

            Employee emp = new Employee();

            Employee[] arr_emp = new Employee[2];
            for (int i = 0; i < 2; i++)
            {
                arr_emp[i] = new Employee();
            }

            // emp.setDetails(employeeId, employeeName, employeeAddress, employeeCity, employeeDepartment);
            // emp.getSalary();

            //Console.WriteLine("ID: " + employeeId + "\nName: " + employeeName + "\nAddress: " + employeeAddress + "\nCity: " + employeeCity + "\nDepartment: " + employeeDepartment);


            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("Enter Employee" + (i + 1) + " ID");
                employeeId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Employee" + (i + 1) + " Name");
                employeeName = Console.ReadLine();

                Console.WriteLine("Enter Employee" + (i + 1) + " Address");
                employeeAddress = Console.ReadLine();

                Console.WriteLine("Enter Employee" + (i + 1) + " City");
                employeeCity = Console.ReadLine();

                Console.WriteLine("Enter Employee" + (i + 1) + " Department");
                employeeDepartment = Console.ReadLine();

               


                arr_emp[i].SetDetails(employeeId, employeeName, employeeAddress, employeeCity, employeeDepartment);
                arr_emp[i].GetSalary();
            }
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("\n");
                Console.WriteLine("Name: " + arr_emp[i].employeeName+ "\tSalary: " + arr_emp[i].Salary);
            }
        }
    }
}
