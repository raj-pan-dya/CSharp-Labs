﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    public class Employee
    {

        int employeeId;
        public string employeeName;
        string employeeAddress;
        string employeeCity;
        string employeeDepartment;
        public double Salary;

        public void SetDetails(int employeeId, string employeeName, string employeeAddress, string employeeCity, string employeeDepartment)
        {
            this.employeeId = employeeId;
            this.employeeName = employeeName;
            this.employeeAddress = employeeAddress;
            this.employeeCity = employeeCity;
            this.employeeDepartment = employeeDepartment;
        }

        public void GetSalary()
        {

            Console.WriteLine("give your salary details");
            Salary = Convert.ToDouble(Console.ReadLine());
        }
    }
}
