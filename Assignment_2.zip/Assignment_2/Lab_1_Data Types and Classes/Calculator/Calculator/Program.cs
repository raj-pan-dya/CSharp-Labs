﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("----Calculator Application----");

            char flag;

            do
            {
                Console.WriteLine("Press 1 for Addition; Press 2 for Subtraction; Press 3 for Multiplication; Press 4 for Division; Press 5 fo Modulus");
                int operation;
                operation = Convert.ToInt32(Console.ReadLine());
                int firstno;
                int secondno;
                Console.WriteLine("Enter first no:");
                firstno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter second no:");
                secondno = Convert.ToInt32(Console.ReadLine());
                float result;

                ArithmeticOperations objCalculator = new ArithmeticOperations();

                switch (operation)
                {
                    case 1:
                        //Logic to add
                        result = objCalculator.Addition(firstno, secondno);
                        Console.WriteLine("Addition is: " + result);
                        break;
                    case 2:
                        //logic to subtract
                        result = objCalculator.Subtraction(firstno, secondno);
                        Console.WriteLine("Subtraction is: " + result);
                        break;
                    case 3:
                        //Logic to multiply
                        result = objCalculator.Multiplication(firstno, secondno);
                        Console.WriteLine("Multiplication is: " + result);
                        break;

                    case 4:
                        //Logic to divide
                        result = objCalculator.Division(firstno, secondno);
                        Console.WriteLine("Division is:" + result);
                        break;

                    case 5:
                        //logic for modulus
                        result = objCalculator.Modulus(firstno, secondno);
                        Console.WriteLine("Modulus is:" + result);
                        break;

                    default:
                        break;

                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit");
                flag = Convert.ToChar(Console.ReadLine());

            } while (flag == 'y');

        }
    }
}
