﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecords
{
    class Program
    {
        static void Main(string[] args)
        {
            Details objdetails = new Details();
            Console.WriteLine("Student Records");

            Console.WriteLine("Enter Roll Number:");
            objdetails.rollNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Student Name:");
            objdetails.studentName = Console.ReadLine();

            Console.WriteLine("Enter Age:");
            objdetails.age = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Enter Gender:");
            objdetails.gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Enter Date Of Birth:");
            objdetails.dateOfBirth = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Address:");
            objdetails.address = Console.ReadLine();

            Console.WriteLine("Enter Percentage:");
            objdetails.percentage = Convert.ToInt64(Console.ReadLine());

            
            
        }
    }
}
