﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecords
{
    public class Details
    {
        internal int rollNumber;
        internal string studentName;
        internal byte age;
        internal char gender;
        internal DateTime dateOfBirth;
        internal string address;
        internal float percentage;

        public int RollNumber
        {
            get
            {
                return rollNumber;
            }
            set
            {
                rollNumber = value;
            }
        }
        public string StudentName
        {
            get
            {
                return studentName;
            }
            set
            {
                studentName = value;
            }
        }
        public byte Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }
        public char Gender
        {
            get
            {
                return gender;
            }
            set
            {
                gender = value;
            }
        }
        public DateTime DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }
            set
            {
                dateOfBirth = value;
            }
        }
        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }
        public float Percentage
        {
            get
            {
                return percentage;
            }
            set
            {
                percentage = value;
            }
        }

    }
}
