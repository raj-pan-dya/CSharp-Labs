﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            char flag;

            do
            {
                Console.WriteLine("\n Press any of the numbers from 1 to 5.");
                int operation;
                operation = Convert.ToInt32(Console.ReadLine());

                switch (operation)
                {
                    case 1:
                        Console.WriteLine("You have selected number 1.");
                        break;

                    case 2:
                        Console.WriteLine("You have selected number 2.");
                        break;

                    case 3:
                        Console.WriteLine("You have selected number 3.");
                        break;

                    case 4:
                        Console.WriteLine("You have selected number 4.");
                        break;

                    case 5:
                        Console.WriteLine("You have selected number 5.");
                        break;

                    default:
                        Console.WriteLine("You have not selected numbers between 1 to 5 and please try again");
                        break;
                }

                Console.WriteLine("\n Do you want to continue? Press 'y' to continue or 'n' to exit.");
                flag = Convert.ToChar(Console.ReadLine());
            }while (flag == 'y' || flag == 'Y');
            Console.ReadKey();
        }
    }
}
