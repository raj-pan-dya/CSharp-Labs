﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    class ContactOps
    {
        public static List<Contact> listObj = new List<Contact>();
        public static void AddContact()
        {
            Contact conObj = new Contact();
            
         

     
            Console.WriteLine("Enter Contact Details:");

            Console.WriteLine("Enter ContactNo: ");
            conObj.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter ContactName: ");
            conObj.ContactName = Console.ReadLine();

            Console.WriteLine("Enter CellNo: ");
            conObj.CellNo = Console.ReadLine();


            listObj.Add(conObj);
            
           
        }
        public static void DisplayContact()
        {
            Contact objContact = new Contact();
            
           Console.WriteLine("Enter Contact No to Display the ContactNo: ");
            int contact =Convert.ToInt32( Console.ReadLine());
            objContact = listObj.Find(emp => emp.ContactNo.Equals(contact));

            Console.WriteLine("ContactNo: "+objContact.ContactNo);
            Console.WriteLine("Contact Name: "+objContact.ContactName);
            Console.WriteLine("Cell No: "+objContact.CellNo);


            

        }

        public static void EditContact()
        {
            Contact objEditContact = new Contact();

            Console.WriteLine("Enter Contact No to Edit Contact: ");
            int contactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Contact Details:");

            Console.WriteLine("Enter contact no:");
            objEditContact.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter contact name:");
            objEditContact.ContactName = Console.ReadLine();

            Console.WriteLine("Enter Cell No:");
            objEditContact.CellNo = Console.ReadLine();

            //objEditContact = listObj.Find(emp=>emp.ContactNo.Equals(contact));

            for (int i=0;i<listObj.Count;i++)
            {
                if(listObj[i].ContactNo==contactNo)
                {
                    listObj[i].ContactNo = objEditContact.ContactNo;
                    listObj[i].ContactName = objEditContact.ContactName;
                    listObj[i].CellNo = objEditContact.CellNo;

                }
            }
        }

        public static void ShowAllContacts()
        {
            Console.WriteLine("List of Contact Details:");
            foreach(Contact objContact in listObj)
            {
                Console.WriteLine("**********************************************************");
                Console.WriteLine("ContactNo: "+objContact.ContactNo + "Contact Name: "+objContact.ContactName + "Cell No: "+objContact.CellNo);
                Console.WriteLine("**********************************************************");
            }
        }

    }
}
