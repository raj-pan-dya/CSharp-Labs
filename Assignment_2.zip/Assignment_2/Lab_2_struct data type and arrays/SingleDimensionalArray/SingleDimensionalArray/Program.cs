﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionalArray
{
    class Program
    {
        static void Main(string[] args)
        {
            SingleDArray();
        }

        static void SingleDArray()
        {
            string[] strCities = new string[5];
            Console.WriteLine("Enter the cities 1 by 1\n");
            for (int i = 0; i < strCities.Length; i++)
            {
               strCities[i] = Console.ReadLine();
                
            }
            Console.WriteLine("Elements in the Array are");
            foreach (string j in strCities)
            {
                Console.WriteLine(j);
            }
            Console.ReadKey();
        }
    }
}
