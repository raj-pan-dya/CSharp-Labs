﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    class Program
    {
        static void Main(string[] args)
        {
            Maths objmath = new Maths();
            Console.WriteLine("Enter a number");
            int Number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter 1 for square or 2 for cube");
            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1:
                    objmath.Square(Number);
                    break;
                case 2:
                    objmath.Cube(Number);
                    break;
                default:
                    break;
            }
        }
    }
}
