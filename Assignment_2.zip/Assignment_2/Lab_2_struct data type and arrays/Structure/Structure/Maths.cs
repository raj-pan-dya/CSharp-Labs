﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    struct Maths
    {
        int Number;


        public void Square(int Number)
        {
            Console.WriteLine("Square of number is:" + (Number * Number));
        }
        public void Cube(int Number)
        {
            Console.WriteLine("Cube of number is:" + (Number * Number * Number));
        }
    }
}
