﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDimensionalArray
{
    class BooksDemo
    {
        static void Main(string[] args)
        {

            string[] collName = { "Book_Title"," Author"," Publisher"," Price" };
            string[,] bookDetails = new string[2, 4];
            Console.WriteLine("\nEnter the String Elements 1 by 1\n");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    bookDetails[i, j] = Console.ReadLine();
                }
            }
            Console.WriteLine("Given Matrix");
            foreach (string n in collName)
            {
                Console.Write(""+n);
            }
            Console.WriteLine();
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    
                    Console.Write(bookDetails[i, j] + "\t");
                }
                Console.Write("\n");
            }
            Console.ReadKey();

        }
    }
}
