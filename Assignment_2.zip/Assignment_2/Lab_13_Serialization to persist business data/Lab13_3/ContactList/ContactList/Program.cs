﻿using System;

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    class Program
    {
        static ArrayList contact = new ArrayList();
        static void Main(string[] args)
        {

            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice: ");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());


                switch (taskFlag)
                {

                    case 1:
                        //ADD
                        ContactOps.AddContact();
                        break;

                    case 2:
                        //Serialize 
                        //Solution of Lab 13_1
                        ContactOps.SerializeListSOAP();
                        break;

                    case 3:
                        //Solution of Lab 13_1
                        contact = ContactOps.DeSerializeListSOAP();
                        break;

                    case 4:
                        //Solution of Lab 13_1
                        ContactOps.ShowAllContacts(contact);

                        break;

                    default:
                        Console.WriteLine("Enter Correct Choice.");
                        break;

                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit.");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("****************************************");
            Console.WriteLine("Press 1 to Add Contact");
            Console.WriteLine("Press 2 to Serialize List using SOAPF");
            Console.WriteLine("Press 3 to DeSerialize List using SOAPF");
            Console.WriteLine("Press 4 to Show All DeSerialize list Contacts");
            Console.WriteLine("****************************************");
        }

    }
}
