﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;



namespace ContactList
{
    [Serializable]
    class ContactOps
    {


        public static void AddContact()
        {
            Contact conObj = new Contact();

            Console.WriteLine("Enter Contact Details:");

            Console.WriteLine("Enter ContactNo: ");
            conObj.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter ContactName: ");
            conObj.ContactName = Console.ReadLine();

            Console.WriteLine("Enter CellNo: ");
            conObj.CellNo = Console.ReadLine();

            Contact.listObj.Add(conObj);


        }




        public static void ShowAllContacts(List<Contact> listObj)
        {
            Console.WriteLine("List of Contact Details:");
            foreach (Contact objContact in listObj)
            {

                Console.WriteLine("ContactNo: {0} Contact Name: {1} Cell No: {2}", objContact.ContactNo, objContact.ContactName, objContact.CellNo);


            }
        }

        //Lab 13_1
        //Serializing Contact list using Binary Formatter 
        public static void SerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\hemangjo\Desktop\164289_Hemangee Joshi_Assignment_2\Lab_13_Serialization to persist business data\Lab13_1 and lab13_2\ContactList\ContactListBF.dat", FileMode.Create);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(stream, Contact.listObj);
            stream.Close();
        }

        //Lab 13_2
        //DeSerializing Contact list using Binary Formatter 
        public static List<Contact> DeSerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\hemangjo\Desktop\164289_Hemangee Joshi_Assignment_2\Lab_13_Serialization to persist business data\Lab13_1 and lab13_2\ContactList\ContactListBF.dat", FileMode.Open);
            BinaryFormatter bin = new BinaryFormatter();
            Contact.listObj1 = bin.Deserialize(stream) as List<Contact>;
            stream.Close();
            return Contact.listObj1;

        }

    }
}
