﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarsCatalog;
using Cars.Enitity;

namespace Question3Modified
{
    class Program
    {
        CarInventory objCarCatalog = new CarInventory();
        static void Main(string[] args)
        {
            int choice;
            string[] colName = { "Sr.No", "Car Makes", "Car Model", "Car Year", "Car Sales Price" };
            Program program = new Program();
            
            Console.WriteLine("************Cars Inventory System*************");
            do
            {
                Console.WriteLine("Select your choice:\n 1)Add car\n 2)Search Car\n 3)Delete Car\n 4)Modify Car details\n 5)Print Cars datails\n 6)Quit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        program.AddCar();
                        break;

                    case 2:
                        program.searchCar();
                        break;

                    case 3:
                        program.deleteCar();
                        break;

                    case 4:
                        program.modifyCar();
                        break;

                    case 5:
                        program.printCars();
                        break;

                    case 6:
                        return;
                    default:
                        Console.Write("You entered wrong choice please select valid choice from the options.\n");
                        break;
                }

            } while (choice != -1);
        }
        private void AddCar()
        {
            try
            {
                Car objCar = new Car();
                Console.WriteLine("Car Make");
                objCar.Make = Console.ReadLine();
                Console.WriteLine("Car Model");
                objCar.Model = Console.ReadLine();
                Console.WriteLine("Car Year");
                objCar.Year = Console.ReadLine();
                Console.WriteLine("Car SalePrice");
                objCar.SalePrice = Convert.ToDouble(Console.ReadLine());
                objCarCatalog.AddCar(objCar);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void searchCar()
        {
            Car objCar = new Car();
            Console.WriteLine("enter Car Year");
            string year = Console.ReadLine();
            objCar = objCarCatalog.SearchCar(year);
            Console.WriteLine("********Car Details*************");
            Console.WriteLine("Make : {0}\n Year: {1}\n Model: {2}\n Sales Price: {3}", objCar.Make, objCar.Year, objCar.Model, objCar.SalePrice);
        }

        private void deleteCar()
        {
            Console.WriteLine("enter Car Model");
            string model = Console.ReadLine();
            objCarCatalog.DeleteCar(model);

        }

        private void modifyCar()
        {
            Car objCar = new Car();
            Console.WriteLine("Car Make");
            objCar.Make = Console.ReadLine();
            Console.WriteLine("Car Model");
            objCar.Model = Console.ReadLine();
            Console.WriteLine("Car Year");
            objCar.Year = Console.ReadLine();
            Console.WriteLine("Car SalePrice");
            objCar.SalePrice = Convert.ToDouble(Console.ReadLine());
            objCarCatalog.ModifyCar(objCar);
        }

        private void printCars()
        {
            Car[] cars = objCarCatalog.ListOfCars();
            Console.WriteLine("********Car Details*************");
            try
            {
                foreach (Car c in cars)
                {

                    Console.WriteLine("Make : {0}\n Year: {1}\n Model: {2}\n Sales Price: {3}", c.Make, c.Year, c.Model, c.SalePrice);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Empty array.");
            }
        }


    }
}
