﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cars.Enitity;

namespace CarsCatalog
{
    public class CarInventory
    {
        Car[] objCars = new Car[1];

        int ctr = 0;

        public void AddCar(Car objCar)
        {
            objCars[ctr++] = objCar;
        }

        public void ModifyCar(Car objCar)
        {
            for (int i = 0; i < objCars.Length; i++)
            {
                if (objCars[i].Model == objCar.Model)
                {
                    objCars[i] = objCar;
                }
            }
        }

        public Car SearchCar(string year)
        {
            Car searchCar = null;
            try
            {
                for (int index = 0; index < objCars.Length; index++)
                {
                    if (objCars[index].Year == year)
                    {
                        searchCar = objCars[index];
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return searchCar;
        }
        
         public Car[] ListOfCars()
         {
            return objCars;
         }

         public void DeleteCar(string model)
         {
              for (int i = 0; i < objCars.Length; i++)
              {
                  if (objCars[i].Model == model)
                  {
                     objCars[i] = null;
                  }
              }
         }

    }
}
