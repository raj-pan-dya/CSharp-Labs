﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cars.Enitity
{
    public class Car
    {
        public string Make;
        public string Model;
        public string Year;
        public double SalePrice;
    }
}
