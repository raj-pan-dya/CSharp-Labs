﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Supplier sup = new Supplier();
            
            Console.WriteLine("Enter no of Suppliers:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1;
            do
            {
                sup.AcceptDetails();
                sup.DisplayDetails();
                i++;
            } while (i <= n);
        }
    }
}
