﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3._4
{
   public class Supplier
    {

        public int id;
        public string name, city, emailId;
        public string phoneNo;

        public void AcceptDetails()
        {
            Console.WriteLine("Enter Supplier Id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Supplier City");
            city = Console.ReadLine();
            Console.WriteLine("Enter Supplier Phone No");
            phoneNo = Console.ReadLine();
            Console.WriteLine("Enter Supplier Email Id");
            emailId = Console.ReadLine();
        }

        public void DisplayDetails()
        {
            Console.WriteLine("Supplier Id       : {0}", id);
            Console.WriteLine("Supplier Name     : {0}", name);
            Console.WriteLine("Supplier City     : {0}", city);
            Console.WriteLine("Supplier Phone No : {0}", phoneNo);
            Console.WriteLine("Supplier Email Id : {0}", emailId);

        }
    }
}
