﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3._1
{
    class Participant
    {
        private int empId;
        private string empName;
        public static string compName;
        private string comp;

        private int foundationMarks;
        private int dotNetMarks;
        private int webBasicsMarks;
        private int totalMarks;
        private int totalObtMarks;
        private float percent;

        public int EmpId
        {
            get
            {
                return this.empId;
            }
            set
            {
                this.empId = value;
            }
        }

        public string EmpName
        {
            get
            {
                return this.empName;
            }
            set
            {
                this.empName = value;
            }
        }

        public string CompName
        {
            get
            {
                return this.comp;
            }
            set
            {
                this.comp = value;
            }
        }

        public int FoundationMarks
        {
            get
            {
                return this.foundationMarks;
            }
            set
            {
                if (value >0 || value <= 100)
                {
                    this.foundationMarks = value;
                }
                else
                {
                    this.foundationMarks = 0;
                }


            }
        }
        public int WebBasicsMarks
        {
            get
            {

                return this.webBasicsMarks;
            }
            set
            {
                if (value > 0 || value <= 100)
                {
                    this.webBasicsMarks = value;
                }
                else
                {
                    this.webBasicsMarks = 0;
                }
            }
        }
        public int DotNetMarks
        {
            get
            {
                return this.dotNetMarks;
            }
            set
            {
                if (value > 0 || value <= 100)
                {
                    this.dotNetMarks = value;
                }
                else
                {
                    this.dotNetMarks = 0;
                }

            }
        }

      

        public Participant()
        {
            //default constructor
        }

        public Participant(int id, string name, string compname)
        {
            //paramaterized constructor
            EmpId = id;
            EmpName = name;
            CompName = compname;
        }

       static Participant()
       {
            //static constructor
            compName = "Corporate Company ";
       }

        public int ObtainedMarks(int FoundationMarks, int WebBasicsMarks, int DotNetMarks)
        {
            totalObtMarks = FoundationMarks + WebBasicsMarks + DotNetMarks;
            return totalObtMarks;
        }

        public float Percentage(int totalObtMarks, int totalMarks)
        {
            percent = (totalObtMarks*100) /totalMarks ;
            return percent;
        }

        public void Display()
        {
            Console.WriteLine("Employee id             : {0}", EmpId);
            Console.WriteLine("Employee Name           : {0}", EmpName);
            Console.WriteLine("Employee Company name   : {0}", CompName);
            Console.WriteLine("Employee Obtainerd Marks: {0}", totalObtMarks);
            Console.WriteLine("Employee percetntage    : {0}", percent);
            Console.WriteLine("Employee company name using static constructor   : {0}", compName);

        }

    }
}
