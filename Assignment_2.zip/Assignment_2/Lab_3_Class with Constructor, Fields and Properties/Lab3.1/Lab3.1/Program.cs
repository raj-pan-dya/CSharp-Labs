﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int id;
            string nm, com;
            int totalMarks = 300;
            int i = 1;
            Console.WriteLine(" Enter the no Employee");
            int n = Convert.ToInt32(Console.ReadLine());

            do
            {

                 Console.WriteLine(" Enter Employee id");
                 id = Convert.ToInt32(Console.ReadLine());

                 Console.WriteLine(" Enter Employee Name");
                 nm =Console.ReadLine();

                 Console.WriteLine("Employee Company name");
                 com = Console.ReadLine();

                 Console.WriteLine(" Enter Foundation Marks:");
                 int m1= Convert.ToInt32(Console.ReadLine());
                 Console.WriteLine(" Enter web basics marks");
                 int m2= Convert.ToInt32(Console.ReadLine());
                 Console.WriteLine(" Enter dot net marks");
                 int m3 = Convert.ToInt32(Console.ReadLine());

                 Participant p1 = new Participant(id,nm,com);

                 p1.FoundationMarks = m1;
                 p1.DotNetMarks = m1;
                 p1.FoundationMarks = m1;
                 int result = p1.ObtainedMarks(m1, m2, m3);
                 p1.Percentage(result, totalMarks);
                 p1.Display();
               
                 Console.WriteLine("Employee company name using static constructor and calling in main method   : {0}", Participant.compName);
                Console.WriteLine();
            } while (i<=n);



        }
    }
}
