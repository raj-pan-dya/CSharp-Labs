﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labworks.Assignments
{
    class Program
    {
        static void Main(string[] args)
        {
            SchoolDemo obj = new SchoolDemo();

            Console.WriteLine("St. Joseph School Database");
            obj.getInputs();
            obj.Display();


        }
    }
}
