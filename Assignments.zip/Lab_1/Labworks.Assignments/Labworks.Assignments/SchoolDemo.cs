﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labworks.Assignments
{
    public class SchoolDemo
    {
        public int rollNumber;
        public string studentName;
        public byte age;
        public char gender;
        public DateTime dateOfBirth;
        public string Address;
        public float percentage;

        public void getInputs()
        {
            Console.WriteLine("Enter Student's RollNo.");
            rollNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student's Name.");
            studentName = Console.ReadLine();
            Console.WriteLine("Enter Student's Age.");
            age = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Enter Student's Gender.");
            gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter Student's Date of Birth.");
            dateOfBirth = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Student's Address.");
            Address = Console.ReadLine();
            Console.WriteLine("Enter Student's Percentage.");
            percentage = float.Parse(Console.ReadLine());
        }
        public void Display()
        {
            Console.WriteLine("Student's Details");
            Console.WriteLine("Student RollNo." + rollNumber);

            Console.WriteLine("Student Name." + studentName);
            
            Console.WriteLine("Student Age." + age);
            
            Console.WriteLine("Student Gender." + gender);
          
            Console.WriteLine("Student Date of Birth." + dateOfBirth);
          
            Console.WriteLine("Student Address." + Address);
         
            Console.WriteLine("Student Percentage." + percentage + "%");
           


        }
    }

}
