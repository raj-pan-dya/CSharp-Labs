﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_lib
{
    public class Employee
    {
        private int salary, employeeId;
        private string employeeName, address, city, department;

        public int EmployeeId
        {
            get
            {
                return employeeId;

            }
            set
            {

                employeeId = value;

            }
        }
        public string EmployeeName
        {
            get
            {
                return employeeName;
            }
            set
            {

                employeeName = value;

            }
        }
        public string Address
        {
            get
            {
                return address;
            }
            set
            {

                address = value;

            }
        }
        public string City
        {
            get
            {
                return city;
 
            }
            set
            {

                city = value;

            }
        }
        public string Department
        {
            get
            {
                return department;

            }
            set
            {

                department = value;

            }
        }


        public int Salary
        {
            get
            {
                return salary;
            }
            set
            {

                salary = value;

            }
        }
        public int GetSalary(string employeeName, string address, string city, string department, int salary, int employeeId)
        {
            EmployeeName = employeeName;
            Address = address;
            City = city;
            Department = department;
            Salary = salary;
            EmployeeId = employeeId;
            return Salary;
        }
    }
}
