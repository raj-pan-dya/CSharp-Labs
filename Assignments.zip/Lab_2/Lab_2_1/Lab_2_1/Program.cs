﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stu = new Student();
            stu.number = Convert.ToInt32( Console.ReadLine());
            stu.cube();
            stu.square();
        }
        public struct Student
        {
            public int number;
            public void cube()
            {
                Console.WriteLine("Cube of No. is  :  " + number * number * number);
            }

            public void square()
            {
                Console.WriteLine("Square of No.  :  " + number * number);
            }

        }
    }
}
