﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labworks.Assignment
{
    class BooksDemo
    {
        static void Main(string[] args)
        {
            string[,] bookDetails = new string[4, 4];
            string[] colName = { "Book Title","Author","Publisher","Price" };
            Console.WriteLine("Please pass Book Details:\nBook Title , Author , Publisher , Price ");
            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    bookDetails[i, j] = Console.ReadLine();
                }
            }
            Console.WriteLine("Book Details:\n");
            foreach (string i in colName)
            {

                Console.Write(" " + i);
            }
            Console.WriteLine("");
            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {

                    Console.Write("\t" + bookDetails[i,j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
}
