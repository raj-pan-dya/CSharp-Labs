﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2_2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int[,] twoD = new int[5,3];
            Console.WriteLine("Pass values to MuliDimensinal Array");
            for (int i = 0; i <twoD.GetLength(0) ; i++)
            {
                for (int j = 0; j < twoD.GetLength(1); j++)
                {
                    twoD[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            for (int i = 0; i < twoD.GetLength(0); i++)
            {
                for (int j = 0; j < twoD.GetLength(1); j++)
                {
                    Console.Write(twoD[i,j]+"\t");
                }
                Console.WriteLine();
            }
            
            
        }

    }
}
