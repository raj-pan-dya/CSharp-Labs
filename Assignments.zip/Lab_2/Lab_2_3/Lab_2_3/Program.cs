﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] city = new string[10];
            for (int i = 0; i < 10; i++)
            {
                city[i] = Console.ReadLine();
            }
            foreach (string str in city)
            {

                Console.WriteLine(str);
            }
        }
    }
}
