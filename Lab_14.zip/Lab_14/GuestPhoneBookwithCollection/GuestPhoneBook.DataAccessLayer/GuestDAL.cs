﻿
/*********************************************************************
 * File                 : GuestDAL.cs
 * Author Name          : Amit Potdar
 * Desc                 : Program to define respective function in Data Access layer.
 * Version              : 1.0
 * Last Modified Date   : 01-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using GuestPhoneBook.Entities;
using GuestPhoneBook.Exceptions;

namespace GuestPhoneBook.DataAccessLayer
{
    public class GuestDAL
    {
        public static List<Guest> guestList = new List<Guest>();

        // Function to add new Guests.

        public bool AddGuestDAL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                guestList.Add(newGuest);
                guestAdded = true;
            }
            catch (SystemException ex)
            {
                throw new GuestPhoneBookException(ex.Message);
            }
            return guestAdded;

        }

        // Function to list all the guests.

        public List<Guest> GetAllGuestsDAL()
        {
            return guestList;
        }

        ////Function to search guest by Id.
        public Guest SearchGuestByIdDAL(int searchGuestID)
        {
            Guest searchGuest = null;
            try
            {
                searchGuest = guestList.Find(guest => guest.GuestID == searchGuestID);
            }
            catch (SystemException ex)
            {
                throw new GuestPhoneBookException(ex.Message);
            }
            return searchGuest;
        }

        //Function to search guest by relationship.

        public List<Guest> SearchGuestByRelationshipDAL(Relation relation)
        {
            List<Guest> searchGuest = new List<Guest>();
            try
            {
                 searchGuest.Add(guestList.Find(guest => guest.GuestRelationship == relation));
            }
            catch (SystemException ex)
            {
                throw new GuestPhoneBookException(ex.Message);
            }
            return searchGuest;
        }

        //Function to update guest.

        public bool UpdateGuestDAL(Guest updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].GuestID == updateGuest.GuestID)
                    {
                        updateGuest.GuestName = guestList[i].GuestName;
                        updateGuest.GuestContactNumber = guestList[i].GuestContactNumber;
                        updateGuest.GuestRelationship = guestList[i].GuestRelationship;
                        guestUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new GuestPhoneBookException(ex.Message);
            }
            return guestUpdated;

        }

       //Function to delete guest.

        public bool DeleteGuestDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                Guest deleteGuest = guestList.Find(guest => guest.GuestID == deleteGuestID);

                if (deleteGuest != null)
                {
                    guestList.Remove(deleteGuest);
                    guestDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new GuestPhoneBookException(ex.Message);
            }
            return guestDeleted;

        }

    }
}
