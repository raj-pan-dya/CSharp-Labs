﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Amit Potdar
 * Desc                 : Program to design Console Application and display the required output.
 * Version              : 1.0
 * Last Modified Date   : 01-Dec-2018
 * Change Description   : Description about the changes implemented
 ********************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using GuestPhoneBook.Entities;
using GuestPhoneBook.BusinessLayer;
using GuestPhoneBook.Exceptions;

namespace GuestPhoneBook.PresentationLayer
{
    class Program
    {
        // Main Fuction.

        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine();
                Console.Write(" Enter your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestByID();
                        break;
                    case 4:
                        SearchGuestByRelationship();
                        break;
                    case 5:
                        UpdateGuest();
                        break;
                    case 6:
                        DeleteGuest();
                        break;
                    case 7:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        //Function to display Menu.

        private static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("\n ================= Guest PhoneBook Menu ==================== ");
            Console.WriteLine(" 1. Add a Guest");
            Console.WriteLine(" 2. List All Guests");
            Console.WriteLine(" 3. Search Guest by ID");
            Console.WriteLine(" 4. Search Guest by Relationship");
            Console.WriteLine(" 5. Update a Guest");
            Console.WriteLine(" 6. Delete a Guest");
            Console.WriteLine(" 7. Exit");
            Console.WriteLine(" ============================================================\n");
           

        }

        //Function Add new guests.

        private static void AddGuest()
        {
            try
            {
                Guest newGuest = new Guest();
                Console.WriteLine();
                Console.WriteLine(" Guest Data Entry:-");
                Console.WriteLine();
                Console.Write(" Enter GuestID : ");
                newGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write(" Enter Guest Name : ");
                newGuest.GuestName = Console.ReadLine();
                Console.Write(" Enter PhoneNumber : ");
                newGuest.GuestContactNumber = Console.ReadLine();

                Console.WriteLine();
                foreach (Relation relation in Enum.GetValues(typeof(Relation)))
                {
                    string value = relation.ToString();
                    Console.WriteLine(value);
                }

                Console.WriteLine();

                Console.Write(" Select from above relationship with guest: ");
                string empRel = Console.ReadLine();
                newGuest.GuestRelationship = (Relation)(Enum.Parse(typeof(Relation), empRel, true));
                bool guestAdded = GuestBL.AddGuestBL(newGuest);

                if (guestAdded)
                    Console.WriteLine(" Guest Added");
                else
                    Console.WriteLine(" Guest not Added");
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to list all guests

        private static void ListAllGuests()
        {
            try
            {
                List<Guest> guestList = GuestBL.GetAllGuestsBL();



                if (guestList != null)
                {
                    Console.WriteLine();
                    Console.WriteLine(" =============================================================================================");
                    Console.WriteLine(" GuestID\t\tName\t\tPhoneNumber\t\tGuest Relationship");
                    Console.WriteLine(" =============================================================================================");

                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine(" {0}\t\t{1}\t\t{2}\t\t\t{3}", guest.GuestID, guest.GuestName, guest.GuestContactNumber, guest.GuestRelationship);
                    }
                    Console.WriteLine(" =============================================================================================");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search any guest by its Id.

        private static void SearchGuestByID()
        {
            try
            {
                int searchGuestID;
                Console.WriteLine();
                Console.Write(" Enter GuestID to Search: ");
                searchGuestID = Convert.ToInt32(Console.ReadLine());
                Guest searchGuest = GuestBL.SearchGuestByIdBL(searchGuestID);
                if (searchGuest != null)
                {
                    Console.WriteLine(" ===========================================================================================");
                    Console.WriteLine(" GuestID\t\tName\t\tPhoneNumber\t\tGuest Relationship");
                    Console.WriteLine(" ===========================================================================================");
                    Console.WriteLine(" {0}\t\t{1}\t\t{2}\t\t\t{3}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.GuestContactNumber,searchGuest.GuestRelationship);
                    Console.WriteLine(" ===========================================================================================");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to search any guest by his/her relationship.

        private static void SearchGuestByRelationship()
        {
            try
            {
                Relation relation;

                string searchGuestReslationship;
                Console.WriteLine();
                Console.Write(" Enter Relationship of guest to Search: ");
                searchGuestReslationship = Console.ReadLine();

                if (Enum.TryParse<Relation>(searchGuestReslationship, true, out relation))
                {
                    List<Guest> searchGuest = GuestBL.SearchGuestByRelationshipBL(relation);
                    if (searchGuest.Count != 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine(" ========================================================================================");
                        Console.WriteLine(" GuestID\t\tName\t\tPhoneNumber\t\tGuest Relationship");
                        Console.WriteLine(" ========================================================================================");
                        foreach (Guest guest in searchGuest)
                        {
                            Console.WriteLine(" {0}\t\t{1}\t\t{2}\t\t\t{3}", guest.GuestID, guest.GuestName, guest.GuestContactNumber, guest.GuestRelationship);
                        }
                        Console.WriteLine(" ========================================================================================");
                    }
                }
                else
                {
                    Console.WriteLine(" No Guest Details Available");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine();
        }

        //Function to update the Guest Details

        private static void UpdateGuest()
        {
            try
            {
                int updateGuestID;
                Console.WriteLine();
                Console.Write(" Enter GuestID to Update Details: ");
                updateGuestID = Convert.ToInt32(Console.ReadLine());
                Guest updatedGuest = GuestBL.SearchGuestByIdBL(updateGuestID);
                if (updatedGuest != null)
                {
                    Console.WriteLine();
                    Console.Write(" Update Guest ID: ");
                    updatedGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                    Console.Write(" Update Guest Name: ");
                    updatedGuest.GuestName = Console.ReadLine();
                    Console.Write(" Update PhoneNumber: ");
                    updatedGuest.GuestContactNumber = Console.ReadLine();
                    bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                    if (guestUpdated)
                    {
                        Console.WriteLine();
                        Console.WriteLine(" Guest Details Updated");
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine(" Guest Details not Updated ");
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine(" No Guest Details Available");
                }


            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Function to delete a guest by his/her Id.

        private static void DeleteGuest()
        {
            try
            {
                int deleteGuestID;
                Console.WriteLine();
                Console.Write(" Enter the GuestID to Delete: ");
                deleteGuestID = Convert.ToInt32(Console.ReadLine());
                Guest deleteGuest = GuestBL.SearchGuestByIdBL(deleteGuestID);
                if (deleteGuest != null)
                {
                    bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                    if (guestdeleted)
                        Console.WriteLine(" Guest Deleted");
                       
                    else
                        Console.WriteLine(" Guest not Deleted ");     
                }
                else
                {
                    Console.WriteLine(" No Guest Details Available");
                }


            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
      
    }
}
